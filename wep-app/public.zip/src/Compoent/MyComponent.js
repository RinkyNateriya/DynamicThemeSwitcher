import React, { useState, useEffect } from 'react';
import '../styles/css/style.css';



  


const MyComponent = () => {
  const [theme, setTheme] = useState('light');
  const [customTheme, setCustomTheme] = useState({
    textColor: 'black',
    bgColor: 'white',
    tableHeaderColor: '#f0f0f0',
    tableCellColor: '#ffffff'
  });

  
// useEffect(() => {
//     const storedTheme = localStorage.getItem('customTheme');
//     if (storedTheme) {
//       setCustomTheme(JSON.parse(storedTheme));
//     }
//   }, []);
useEffect(() => {
    const storedTheme = localStorage.getItem('customTheme');
    if (storedTheme) {
      setCustomTheme(JSON.parse(storedTheme));
    }
  }, []);


  const handleColorChange = (color, field) => {
    setCustomTheme({
      ...customTheme,
      [field]: color
    });

    if (field === 'bgColor') {
      setCustomTheme({
        ...customTheme,
        tableCellColor: color
      });
    }
    localStorage.setItem("customTheme", JSON.stringify(customTheme));
  };



  const toggleTheme = async() => {
    setTheme(theme === 'light' ? 'dark' : 'light');
    if (theme === 'light') {
      setCustomTheme({
        textColor: 'white',
        bgColor: 'black',
        tableHeaderColor: '#333',
        tableCellColor: '#444'
      });
    } else {
      setCustomTheme({
        textColor: 'black',
        bgColor: 'white',
        tableHeaderColor: '#f0f0f0',
        tableCellColor: '#ffffff'
      });
await demo()
    }

    

  };
const demo=()=>{
    setTimeout(() => {
        localStorage.setItem("customTheme", JSON.stringify(customTheme));

      }, 1000); // 1000 milliseconds = 1 second
      
}


  return (
    <div className={`container ${theme}`} style={{ color: customTheme.textColor, backgroundColor: customTheme.tableCellColor }}>
      <table className={`table mt-1 ${theme}`}>
       
        <tbody>
          <tr>
            <td style={{ color: customTheme.textColor, backgroundColor: customTheme.tableCellColor }}>1</td>
            <td style={{ color: customTheme.textColor, backgroundColor: customTheme.tableCellColor }}>Mark</td>
            <td style={{ color: customTheme.textColor, backgroundColor: customTheme.tableCellColor }}>Otto</td>
            <td style={{ color: customTheme.textColor, backgroundColor: customTheme.tableCellColor }}>@mdo</td>
          </tr>
        </tbody>
      </table>

      <div className='container'>
        <button onClick={toggleTheme} type="button" className="btn btn-primary">
        toggle
          {/* {theme === 'light' ? 'Enable Light Mode' : 'Enable Dark Mode'} */}
        </button>
        <div>
          <label>Text Color:</label>
          <input type="color" value={customTheme.textColor} onChange={(e) => handleColorChange(e.target.value, 'textColor')} />
        </div>
        <div>
          <label>Background Color:</label>
          <input type="color" value={customTheme.bgColor} onChange={(e) => handleColorChange(e.target.value, 'bgColor')} />
        </div>
      </div>
    </div>
  );
};

export default React.memo(MyComponent);
