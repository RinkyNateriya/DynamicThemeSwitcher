import './App.css';
import MyComponent from './Compoent/MyComponent';

function App() {
  return (
  <div className="App">
<MyComponent/>
    </div>  
  );
}
export default App;
